package CT;

public class StringCompare {

  public static double similarity(String qn, String qu, double count ) {
    
		 
		 double tot=qn.split("\\s+").length;
		double tf=0;
		String words[]=qu.split("\\s+");
		for(String w:words){
		tf=tf+CountWords.main(qn,w);
		}

		tf=tf/tot;

		double idf=Math.log(count/1);


		System.out.println(qn);
				System.out.println(tf+"		tot"+count+"		"+idf);

		
		return tf*idf;
	
  }

  

  public static void main(String[] args) {
  
  }

}