package CT;

public class StringCompare {

  public static double similarity(String qn, String qu, double count ) {
    
		 
		 double tot=qn.split("\\s+").length;
		double freq=0;
		String words[]=qu.split("\\s+");
		for(String w:words){
		freq=freq+CountWords.main(qn,w);
		}

		tot=tot/freq;

		tot=1/tot;

		double score=Math.log(tot);
		


		return score;
	
  }

  

  public static void main(String[] args) {
  
  }

}